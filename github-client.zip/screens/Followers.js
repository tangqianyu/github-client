import * as React from "react";
export default class Following extends React.Component {
  render() {
    return null;
  }
}
